#ifndef JAF_STATISTICS
#define JAF_STATISTICS

double jaf_sum(double * numbers, int size);

#endif